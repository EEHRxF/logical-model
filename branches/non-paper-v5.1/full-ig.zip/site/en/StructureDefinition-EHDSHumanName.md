# Human name model - EHDS Logical Information Models v0.3.0

## Logical Model: Human name model 

**Usages:**

* Use this Logical Model: [Health professional model](StructureDefinition-EHDSHealthProfessional.md), [Patient model](StructureDefinition-EHDSPatient.md) and [Related person model](StructureDefinition-EHDSRelatedPerson.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/eu.ehds.models|current/StructureDefinition/StructureDefinition-EHDSHumanName.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-EHDSHumanName.csv), [Excel](../StructureDefinition-EHDSHumanName.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "EHDSHumanName",
  "url" : "http://ehds.eu/fhir/models/StructureDefinition/EHDSHumanName",
  "version" : "0.3.0",
  "name" : "EHDSHumanName",
  "title" : "Human name model",
  "status" : "draft",
  "date" : "2026-11-21T16:13:39+00:00",
  "publisher" : "EC",
  "contact" : [{
    "name" : "EC",
    "telecom" : [{
      "system" : "url",
      "value" : "http://commission.europa.eu/"
    }]
  }],
  "description" : "EHDSHumanName means a structured set of data elements describing the name of a person.",
  "fhirVersion" : "5.0.0",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "logical",
  "abstract" : false,
  "type" : "http://ehds.eu/fhir/models/StructureDefinition/EHDSHumanName",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "EHDSHumanName",
      "path" : "EHDSHumanName",
      "short" : "Human name model",
      "definition" : "EHDSHumanName means a structured set of data elements describing the name of a person."
    },
    {
      "id" : "EHDSHumanName.use",
      "path" : "EHDSHumanName.use",
      "short" : "The purpose of this name.",
      "definition" : "The purpose of this name.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "description" : "HL7 Name Use"
      }
    },
    {
      "id" : "EHDSHumanName.text",
      "path" : "EHDSHumanName.text",
      "short" : "The entire name as it shall be displayed, e.g. on an application UI.",
      "definition" : "The entire name as it shall be displayed, e.g. on an application UI.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "EHDSHumanName.family",
      "path" : "EHDSHumanName.family",
      "short" : "The family name / surname / last name.",
      "definition" : "The family name / surname / last name.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "EHDSHumanName.given",
      "path" : "EHDSHumanName.given",
      "short" : "The given name / first name.",
      "definition" : "The given name / first name.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "EHDSHumanName.prefix",
      "path" : "EHDSHumanName.prefix",
      "short" : "Name part that appears at the start of the name. Prefixes shall appear in the correct order for presenting the name.",
      "definition" : "Name part that appears at the start of the name. Prefixes shall appear in the correct order for presenting the name.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "EHDSHumanName.suffix",
      "path" : "EHDSHumanName.suffix",
      "short" : "Name part that appears at the end of the name. Suffixes shall appear in the correct order for presenting the name.",
      "definition" : "Name part that appears at the end of the name. Suffixes shall appear in the correct order for presenting the name.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
