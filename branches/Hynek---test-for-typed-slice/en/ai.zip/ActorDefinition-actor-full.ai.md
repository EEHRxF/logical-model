# Full - EHDS Logical Information Models v0.1.0

## ActorDefinition: Full 



## Resource Content

```json
{
  "resourceType" : "ActorDefinition",
  "id" : "actor-full",
  "url" : "https://ehds.eu/specifications/fhir/actor-full",
  "version" : "0.1.0",
  "name" : "Full",
  "status" : "active",
  "date" : "2026-07-24T10:04:43+00:00",
  "publisher" : "EC",
  "contact" : [{
    "name" : "EC",
    "telecom" : [{
      "system" : "url",
      "value" : "http://commission.europa.eu/"
    }]
  }],
  "type" : "system"
}

```
